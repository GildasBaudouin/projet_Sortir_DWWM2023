<?php

namespace App\Controller;
use App\Entity\Site;
use App\Entity\User;
use App\Form\UserUpdateType;
use App\Repository\SiteRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\CurrentUser;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/user/', name: 'user_')]
class UserController extends AbstractController
{
    #[Route('updateProfil', name: 'updateProfil')]
    public function updateProfil(Request $request, EntityManagerInterface $entityManager, SluggerInterface $slugger, #[CurrentUser] $user): Response{


        $updateForm = $this->createForm(UserUpdateType::class, $user);
        $updateForm->handleRequest($request);

        if($updateForm->isSubmitted() && $updateForm->isValid()){
            $profileFile = $updateForm->get('image')->getData();

            if ($profileFile) {
                $originalFilename = pathinfo($profileFile->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $slugger->slug($originalFilename);
                $newFilename = $safeFilename . '-' . uniqid() . '.' . $profileFile->guessExtension();
                $profileFile->move($this->getParameter('profile_directory'), $newFilename);
                $user->setImage($newFilename);
            }
           //
            $entityManager->persist($user);
            $entityManager->flush();
            $this->addFlash('success', 'Profil modifié !');
            return $this->redirectToRoute('event_list');
        }

        return $this->render('user/updateProfil.html.twig', [
            'updateForm' => $updateForm->createView(),
        ]);
    }

    #[Route('display/{id}', name: 'display')]
    public function displayProfile(int $id, UserRepository $userRepository, EntityManagerInterface $em): Response {

        $user = $userRepository->find($id);
        $site = $user->getSite();

        if (!$user) {
            throw $this->createNotFoundException('user introuvable');
        }

        return $this->render('user/display.html.twig', [
           'user'=> $user,
            'site'=>$site
        ]);
    }

/*
    public function new(Request $request): Response
    {
        $user = $this->getUser();
        $affiche = new User();
        $lesRubriques = $this->getUser()
            ->getUserIdentifier(User::class)
            ->findAll();
        $form = $this->createForm(User::class, $affiche);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $entityManager = $this->getUser()->getUserIdentifier();
            $entityManager->persist($affiche);
            $entityManager->flush();
            return $this->render('user/profil.html.twig');
        }

            return $this->redirectToRoute ('user_updateProfil', [
            'update' => $affiche,
            'form' => $form->createView(),
            'laSection' => $user->getUserIdentifier(),
            'lesRubriques' => $lesRubriques,
        ]);
    }

*/

}
