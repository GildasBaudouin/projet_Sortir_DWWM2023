<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\FileCSVType;
use App\Form\RegistrationFormType;
use App\Repository\SiteRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;

#[Route('/admin', name: 'admin_')]
class RegistrationController extends AbstractController
{
    #[Route('/register', name: 'app_register')]
    public function register(Request                     $request,
                             UserPasswordHasherInterface $userPasswordHasher,
                             EntityManagerInterface      $entityManager,
                             UserRepository              $ur): Response
    {
        $user = new User();
        $form = $this->createForm(RegistrationFormType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setRoles(['ROLE_USER']);


            $user->setIsActive(true);
            $user->setPassword(
                $userPasswordHasher->hashPassword(
                    $user,
                    $form->get('plainPassword')->getData()
                )
            );

            //donne le role admin au 1er user
            if (!$ur->findAll()) {
                $user->setRoles(["ROLE_ADMIN", "ROLE_USER"]);
            }
            $entityManager->persist($user);
            $entityManager->flush();

            //login l'admin directement
            if (in_array("ROLE_ADMIN", $user->getRoles())) {
                $token = new UsernamePasswordToken($user, 'main', $user->getRoles());
                $this->container->get('security.token_storage')->setToken($token);
                $request->getSession()->set('_security_main', serialize($token));
            }

            return $this->redirectToRoute('event_list');
        }

        return $this->render('registration/register.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }

    #[Route('/admin', name: 'app_admin')]
    public function adminRegister()
    {

        $admin = $this->getUser();
        $isAdmin = in_array("ROLE_ADMIN", $admin->getRoles());

        if (!$isAdmin) {
            $this->addFlash('error', 'Vous n\'avez pas l\'autorisation !');
            return $this->redirectToRoute('event_list');
        }

//        if ($admin->getRoles() != "ROLE_ADMIN"){
//
//        }
        return $this->redirectToRoute('admin_app_register');
    }

    #[Route('/registerCSV', name: 'registerCSV')]
    public function registerByCSV(Request $request, EntityManagerInterface $em, UserPasswordHasherInterface $userPasswordHasher, SiteRepository $siteRepository, UserRepository $userRepository)
    {

        $fileForm = $this->createForm(FileCSVType::class);
        $fileForm->handleRequest($request);

        if ($fileForm->isSubmitted() && $fileForm->isValid()) {
            $file = $fileForm->get('attachment')->getData();

            if (($fileOpen = fopen($file->getPathname(), "r")) !== false) {
                $booleanFile = false;

                while (($data = fgetcsv($fileOpen, 0, ';')) !== false) {

                    if ($booleanFile) {
                        $site = $siteRepository->findOneBy(['name' => $data[6]]);

                        $user = new User();
                        $user->setLogin($data[0]);
                        $user->setRoles(['ROLE_USER']);
                        $user->setPassword($userPasswordHasher->hashPassword(
                            $user,
                            $data[1]
                        ));
                        $user->setName($data[2]);
                        $user->setFirstName($data[3]);
                        $user->setEmail($data[4]);
                        $user->setPhone($data[5]);
                        $user->setSite($site);
                        $user->setIsActive(true);
                        $em->persist($user);
//                        dd($data, $user);
                    } else {
                        $booleanFile = true;
                    }
                }
                fclose($fileOpen);
                $em->flush();
            }

            return $this->redirectToRoute('event_list');
        }
        return $this->render('registration/registerCSV.html.twig', [
            'fileForm' => $fileForm->createView(),
        ]);
    }

}