<?php

namespace App\Controller;


use App\Entity\Etat;
use App\Entity\Lieu;
use App\Entity\Site;
use App\Entity\Sortie;
use App\Entity\User;
use App\Entity\Ville;
use App\Form\CancelType;
use App\Form\SortieType;
use App\Repository\LieuRepository;
use App\Repository\SiteRepository;
use App\Repository\SortieRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\RadioType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


#[Route('/event/', name: 'event_')]
class SortieController extends AbstractController
{

    //CRU - - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -

    // TEMPLATE CREATE/UPDATE

    /**
     * @param Sortie|null $sortie
     * @param Request $request
     * @param EntityManagerInterface $entityManager
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     */
    public function templateSortie(?Sortie $sortie, Request $request, EntityManagerInterface $entityManager): Response|\Symfony\Component\HttpFoundation\RedirectResponse
    {

        $sortieForm = $this->createForm(SortieType::class, $sortie);
        $sortieForm->handleRequest($request);

        //set l'état en créée
        if ($sortieForm->isSubmitted() && $sortieForm->isValid()) {
            $sortie->setEtat($entityManager->find(Etat::class, 1));
            $sortie->setUser($this->getUser());

            //set l'état en publiée
            if ($sortieForm->get('etat')->isClicked()) {
                $sortie->setEtat($entityManager->find(Etat::class, 2));

                //donne le site de l'user a la sortie
                $idSite = $this->getUser()->getSite()->getId();
                $userSite = $entityManager->find(Site::class, $idSite);
                $sortie->setSite($userSite);

                $entityManager->persist($sortie);
                $entityManager->flush();

                $this->addFlash('success', 'Sortie publiée !');
                return $this->redirectToRoute('event_list');
            }

            //donne le site de l'user a la sortie
            $idSite = $this->getUser()->getSite()->getId();
            $userSite = $entityManager->find(Site::class, $idSite);
            $sortie->setSite($userSite);

            $entityManager->persist($sortie);
            $entityManager->flush();

            $this->addFlash('success', 'Sortie enregistrée !');
            return $this->redirectToRoute('event_list');
        }
        return $this->render('sortie/create.html.twig', [
            'sortieForm' => $sortieForm->createView(),
            'sortie' => $sortie
        ]);
    }


    // C  - - -- - - - - - - - - - - -- - - - - - - - - - - -

    #[Route('create', name: 'create')]
    public function create(Request $request, EntityManagerInterface $entityManager): Response
    {
        $sortie = new Sortie();

        return $this->templateSortie($sortie, $request, $entityManager);
    }

    // R - - -- - - - - - - - - - - -- - - - - - - - - - - -

    #[Route('list', name: 'list')]
    public function list(SortieRepository $sortieRepository, SiteRepository $siteRepository, Request $request, EntityManagerInterface $entityManager): Response
    {

        if (!$this->getUser()){
            return $this->redirectToRoute('app_login');
        }

        $idUser = $this->getUser()->getId();

        $filterForm = $this->createFormBuilder()
            ->add('Site', EntityType::class, [
                'class' => Site::class,
                'choice_label' => 'name',
                'required' => false
            ])
            ->add('name', TextType::class, [
                'required' => false
            ])
            ->add('dateDebut', DateType::class, [
                'widget' => 'single_text',
                'required' => false
            ])
            ->add('dateFin', DateType::class, [
                'widget' => 'single_text',
                'required' => false
            ])

            ->add(
                'radioButton', ChoiceType::class,
                [
                    'label' => false,
                    'choices' => array (
                        'Sorties auxquelles je suis inscrit' => 'inscrit',
                        'Sorties auxquelles je ne suis pas inscrit' => 'pasInscrit',
                    ),
                    'expanded' => true,
                    'required'=>false,
                    'placeholder'=>false,
                ])

            ->add('organisateurCheckBox', CheckboxType::class, [
                'label' => 'Sorties dont je suis l\'organisateur/trice',
                'required' => false,
            ])
//            ->add('InscritCheckBox', CheckboxType::class, [
//                'label' => 'sorties auxquelles je suis inscrit',
//                'required' => false,
//            ])
//            ->add('PasInscritCheckBox', CheckboxType::class, [
//                'label' => 'sorties auxquelles je ne suis pas inscrit',
//                'required' => false,
//            ])
            ->add('passeeCheckBox', CheckboxType::class, [
                'label' => 'Sorties passées',
                'required' => false,
            ])
            ->getForm();
//
        $filterForm->handleRequest($request);

        if ($filterForm->isSubmitted() && $filterForm->isValid()) {
            $data = $filterForm->getData();
            $sorties = $sortieRepository->findSorties($data, $idUser);
        } else {
            $sorties = $sortieRepository->findAll();
        }

        $date = new \DateTime('now');
        return $this->render('sortie/list.html.twig', [
            'sorties' => $sorties,
            'filterForm' => $filterForm->createView(),
            'datejour' => $date,
        ]);
    }

    #[Route('details/{id}', name: 'details')]
    public function details(int $id, SortieRepository $sortieRepository): Response
    {

        $sortie = $sortieRepository->find($id);
        $lieu = $sortie->getLieu();
        $ville = $lieu->getVilles();
        if (!$sortie) {
            throw $this->createNotFoundException('Sortie introuvable');
        }

        return $this->render('sortie/details.html.twig', [
            'sortie' => $sortie,
            'lieu' => $lieu,
            'ville' => $ville
        ]);
    }

    // U - - -- - - - - - - - - - - -- - - - - - - - - - - -

    #[Route('updateSortie/{id}', name: 'updateSortie')]
    public function updateSortie(int $id, SortieRepository $sortieRepository, Request $request, EntityManagerInterface $entityManager): Response
    {
        $sortie = $sortieRepository->find($id);
        return $this->templateSortie($sortie, $request, $entityManager);

    }


    // AUTRES FONCTIONS - - -- - - - - - - - - - - -- - - - - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - - - - - -- - - - - - - -- - - - - - - - - - - -

    // ANNULATION

    #[Route('cancel/{id}', name: 'cancel')]
    public function cancelForm(int $id, SortieRepository $sortieRepository, EntityManagerInterface $em, Request $request): Response
    {


        $sortie = $sortieRepository->find($id);

        $site = $em->find(Site::class, $sortie->getSite());
        $lieu = $em->find(Lieu::class, $sortie->getLieu());
        $ville = $em->find(Ville::class, $lieu->getVilles());
        $etat = $sortie->getEtat();

        if ($etat->getId() == 6) {
            $this->addFlash('error', 'Sortie déjà annulée');
            return $this->redirectToRoute('event_list');
        }

        $cancelForm = $this->createForm(CancelType::class, $sortie);
        $cancelForm->handleRequest($request);


        if ($cancelForm->isSubmitted() && $cancelForm->isValid()) {

            //TODO faire marcher ce form de mort

            $sortie->setEtat($em->find(Etat::class, 6));
            $em->persist($sortie);
            $em->flush();

            $this->addFlash('success', 'Sortie annulée !');
            return $this->redirectToRoute('event_list');

        }

        return $this->render('sortie/cancel.html.twig', [
            'sortie' => $sortie,
            'site' => $site,
            'lieu' => $lieu,
            'ville' => $ville,
            'cancelForm' => $cancelForm

        ]);

    }


    //  INSCRIPTION  - -- - - - - - - - - - - - - -- - - - - - - - - - - -

    #[Route('inscrire/{id}', name: 'inscrire')]
    public function inscrireParticipant(int $id, SortieRepository $sortieRepository, UserRepository $userRepository, EntityManagerInterface $em): Response
    {
        $dateJour = new \DateTime('now');

        $sortie = $sortieRepository->find($id);
        $inscriptions = $sortie->getParticipants();
        $userId = $this->getUser()->getId();
        $participant = $em->find(User::class, $userId);

        //TODO try catch date & etat
//
//        if ($inscriptions->isEmpty()) {
//            if ($sortie->getEtat()->getId() == 2 && $sortie->getDateLimiteInscription() > $dateJour) {
//
//                $sortie->addParticipant($participant);
//
//                $em->persist($sortie);
//                $em->flush();
//
//                $this->addFlash('success', 'Vous êtes inscrit !');
//                return $this->redirectToRoute('event_list');
//            }
//        }
        if ($inscriptions->contains($participant)) {
            $this->addFlash('error', 'Vous êtes déjà inscrit à cette sortie');
        } else {
            if ($sortie->getEtat()->getId() == 2 && $sortie->getDateLimiteInscription() > $dateJour) {

                if (count($sortie->getParticipants()) >= $sortie->getNbInscriptionMax()){
                    $this->addFlash('error', 'Plus de place !');
                    return $this->redirectToRoute('event_list');
                }
                $sortie->addParticipant($participant);

                $em->persist($sortie);
                $em->flush();

                $this->addFlash('success', 'Vous êtes inscrit !');
            } else {
                $this->addFlash('error', 'Inscription impossible');
            }
        }
        return $this->redirectToRoute('event_list');
    }


    // DESISTEMENT - - -- - - - - - - - - - - -- - - - - - - -

    #[Route('/event/desister/{id}', name: 'desister')]
    public function desister(int $id, SortieRepository $sr, EntityManagerInterface $em){


        $sortie = $sr->findInscriptions($id);
        $participant = $this->getUser();
        $sortie->removeUser($participant);

        $em->persist($sortie);
        $em->flush();

        $this->addFlash('success', 'Vous n\'êtes plus inscrit à cette sortie');

        return $this->redirectToRoute('event_list');

    }

    // ADMIN REGISTER - -- - - - - - - - - - - - - -- - - - - - - - - - - -






}
