<?php

namespace App\Controller;

use App\Entity\Lieu;
use App\Repository\LieuRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


#[Route('/lieu', name: 'lieu_')]
class LieuController extends AbstractController
{
    #[Route('/infos/{id}', name: 'infos')]
    public function infos(Lieu $lieu): JsonResponse
    {
        return $this->json([
            'ville' => $lieu->getVilles()->getNom(),
            'cp' => $lieu->getVilles()->getCodePostal(),
            'rue' => $lieu->getRue(),
            'latitude' => $lieu->getLatitude(),
            'longitude' => $lieu->getLongitude(),
        ]);
    }
}
