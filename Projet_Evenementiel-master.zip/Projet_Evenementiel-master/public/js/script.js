// affichage dynamique du lieu

(() => {
        const selectElement = document.getElementById('sortie_lieu');

        //pour une sortie qui à déjà un lieu (twig modif)
        let currentElement = selectElement.options[selectElement.selectedIndex].value;
        setInformation(currentElement);
        selectElement.addEventListener("change", function (e) {
            setInformation(e.target.value);
        });
        function setInformation(lieuId){
            console.log(lieuId);
            if(lieuId === ""){
                document.getElementById('lieuVille').textContent = '';
                document.getElementById('lieuRue').textContent = '';
                document.getElementById('lieuCp').textContent = '';
                document.getElementById('lieuLatitude').textContent = '';
                document.getElementById('lieuLongitude').textContent = '';
            }
            else {
                fetch(`/Projet_Evenementiel/public/lieu/infos/${lieuId}`)
                    .then(function(response) {
                        return response.json();
                    })
                    .then(function(lieu) {
                        document.getElementById('lieuVille').textContent = lieu.ville;
                        document.getElementById('lieuRue').textContent = lieu.cp;
                        document.getElementById('lieuCp').textContent = lieu.rue;
                        document.getElementById('lieuLatitude').textContent = lieu.latitude;
                        document.getElementById('lieuLongitude').textContent = lieu.longitude;
                    });
            }
        }
})();


function actionAlert(ok){
    if (ok)
    {
        alert("Oui !");
        return true;
    }
    else
    {
        alert("En fait non");
        return false;
    }
}

function actionDesist()
{
    let ok = confirm("Voulez-vous vraiment vous désister ?");
    actionAlert(ok)
}


/* toggle password twig update user */

function togglePassword() {
    let firstPassword = document.getElementById("user_update_password_first");
    let secondPassword = document.getElementById("user_update_password_second");
    if (firstPassword.type === "password") {
        firstPassword.type = "text";
        secondPassword.type = "text";
    } else {
        firstPassword.type = "password";
        secondPassword.type = "password";
    }
}




